# 📰 Fake News / Misinformation Detector

An NLP project that classifies news headlines and articles as **reliable** or **misleading**,
with a web interface and word-level explanations of each prediction.

## Problem Statement
Misinformation spreads faster than manual fact-checking can keep up. This project builds an
automated first-pass filter that flags news text likely to be fake, so readers and moderators
know what to verify first.

## Features
- Text cleaning pipeline (URL/HTML removal, agency-tag stripping to prevent data leakage)
- TF-IDF (unigrams + bigrams) feature extraction
- Compares 4 classifiers: Logistic Regression, Linear SVM, Passive Aggressive, Multinomial Naive Bayes
- Auto-selects the best model by F1-score and saves it
- Explainability: shows which words pushed the prediction toward fake or reliable
- Streamlit web app + command-line predictor
- Unit tests

## Tech Stack
Python, scikit-learn, pandas, NumPy, Matplotlib, Streamlit, pytest

## Project Structure
```
fake-news-detector/
├── app.py               # Streamlit web app
├── src/
│   ├── preprocess.py    # text cleaning
│   ├── train.py         # train + compare + save model
│   └── predict.py       # inference + explanation
├── tests/               # unit tests
├── data/                # put Fake.csv and True.csv here
├── models/              # trained model is saved here
└── reports/             # metrics.json and confusion matrix
```

## Setup
```bash
git clone https://github.com/<your-username>/fake-news-detector.git
cd fake-news-detector
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Dataset
Download the [ISOT Fake News Dataset](https://www.kaggle.com/datasets/clmentbisaillon/fake-and-real-news-dataset)
and place `Fake.csv` and `True.csv` inside `data/`.

## Usage
```bash
python -m src.train --data-dir data          # train and evaluate
python -m src.predict "Some headline here"   # CLI prediction
streamlit run app.py                         # web app
pytest                                       # run tests
```

## Results
Fill this in after training (see `reports/metrics.json`):

| Model | Accuracy | F1 |
|-------|----------|----|
| Logistic Regression | | |
| Linear SVM | | |
| Passive Aggressive | | |
| Multinomial NB | | |

Add your `reports/confusion_matrix.png` and a screenshot of the app here.

## Limitations
- The model learns **writing style and vocabulary** of its training data; it does not verify facts.
- ISOT is mostly US political news from 2016-2017, so accuracy on other topics, regions or
  time periods will be lower than the test score suggests.
- Very high accuracy on this dataset is partly due to source-specific cues. Cross-dataset
  evaluation is recommended.

## Future Improvements
- Fine-tune a transformer (BERT / DistilBERT) and compare with the baseline
- Evaluate on a second dataset (e.g., LIAR, WELFake) to test generalization
- Add multilingual / Hindi support
- Deploy on Streamlit Community Cloud or Hugging Face Spaces
- Add source credibility and fact-check API lookups

## License
MIT
