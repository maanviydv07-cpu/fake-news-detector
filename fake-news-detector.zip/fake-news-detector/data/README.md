# Dataset

Download the **ISOT Fake News Dataset** (also on Kaggle as "Fake and real news dataset")
and place these two files in this folder:

- `Fake.csv`
- `True.csv`

Both files have the columns: `title, text, subject, date`.
Dataset files are git-ignored because of their size.
