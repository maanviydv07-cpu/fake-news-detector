from src.preprocess import clean_text


def test_lowercase_and_punctuation():
    assert clean_text("Hello, World! 123") == "hello world"


def test_removes_urls_and_html():
    assert clean_text("Visit https://x.com <b>now</b>") == "visit now"


def test_strips_reuters_tag():
    assert clean_text("WASHINGTON (Reuters) - Senate passes bill") == "senate passes bill"


def test_non_string_returns_empty():
    assert clean_text(None) == ""
