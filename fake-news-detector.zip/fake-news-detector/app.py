"""Streamlit web app. Run with: streamlit run app.py"""
import streamlit as st

from src.predict import load_model, predict

st.set_page_config(page_title="Fake News Detector", page_icon="📰")
st.title("📰 Fake News / Misinformation Detector")
st.caption("Paste a news headline or article. The model estimates whether it looks reliable or misleading.")


@st.cache_resource
def get_model():
    return load_model()


try:
    model = get_model()
except FileNotFoundError as e:
    st.error(str(e))
    st.stop()

text = st.text_area("News headline or article", height=220,
                    placeholder="Paste text here...")

if st.button("Analyze", type="primary"):
    if len(text.split()) < 5:
        st.warning("Please enter at least a few words.")
    else:
        res = predict(text, model)
        if res["label"] == 1:
            st.success(f"✅ {res['verdict']}")
        else:
            st.error(f"🚩 {res['verdict']}")
        st.progress(res["confidence"], text=f"Confidence: {res['confidence']:.1%}")

        st.subheader("Words that influenced the decision")
        for word, w in res["top_words"]:
            arrow = "→ reliable" if w > 0 else "→ fake"
            st.write(f"`{word}` {arrow} ({w:+.3f})")

st.divider()
st.caption("⚠️ This is a statistical text classifier, not a fact-checker. "
           "It learns writing style from its training data, so always verify important claims with trusted sources.")
