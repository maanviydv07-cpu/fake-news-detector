"""Text cleaning utilities."""
import re

# Real articles in the ISOT dataset often start with "CITY (Reuters) -".
# Leaving it in lets a model "cheat" by spotting the agency tag, so we strip it.
_AGENCY_PREFIX = re.compile(r"^[^()]{0,60}\(reuters\)\s*-?\s*")
_URL = re.compile(r"http\S+|www\.\S+")
_HTML = re.compile(r"<.*?>")
_NON_ALPHA = re.compile(r"[^a-z\s]")
_SPACES = re.compile(r"\s+")


def clean_text(text) -> str:
    """Lowercase, remove agency tags, URLs, HTML, punctuation and digits."""
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = _AGENCY_PREFIX.sub("", text)
    text = _URL.sub(" ", text)
    text = _HTML.sub(" ", text)
    text = _NON_ALPHA.sub(" ", text)
    return _SPACES.sub(" ", text).strip()
