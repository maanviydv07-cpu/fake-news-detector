"""Inference helpers: load the model, predict, and explain a prediction.

Usage:
    python -m src.predict "Your headline or article text here"
"""
import sys
from pathlib import Path

import joblib
import numpy as np

from src.preprocess import clean_text

MODEL_PATH = Path(__file__).resolve().parent.parent / "models" / "model.joblib"
LABELS = {0: "Misleading / Fake", 1: "Reliable"}


def load_model(path: Path = MODEL_PATH):
    if not Path(path).exists():
        raise FileNotFoundError("Model not found. Run `python -m src.train` first.")
    return joblib.load(path)


def _prob_real(clf, X) -> float:
    if hasattr(clf, "predict_proba"):
        return float(clf.predict_proba(X)[0, 1])
    score = float(clf.decision_function(X)[0])  # e.g. LinearSVC: squash margin
    return float(1 / (1 + np.exp(-score)))


def predict(text: str, pipe, top_n: int = 8) -> dict:
    """Return label, confidence and the words that influenced the decision."""
    vec, clf = pipe.named_steps["tfidf"], pipe.named_steps["clf"]
    X = vec.transform([clean_text(text)])
    p_real = _prob_real(clf, X)
    label = int(p_real >= 0.5)

    # Per-word contribution = tf-idf value * model weight (+ -> real, - -> fake)
    if hasattr(clf, "coef_"):
        weights = clf.coef_[0]
    else:
        weights = clf.feature_log_prob_[1] - clf.feature_log_prob_[0]
    names = vec.get_feature_names_out()
    coo = X.tocoo()
    contrib = sorted(((names[j], float(v * weights[j])) for j, v in zip(coo.col, coo.data)),
                     key=lambda t: abs(t[1]), reverse=True)[:top_n]

    return {
        "label": label,
        "verdict": LABELS[label],
        "confidence": p_real if label else 1 - p_real,
        "top_words": contrib,
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit('Usage: python -m src.predict "text to check"')
    result = predict(" ".join(sys.argv[1:]), load_model())
    print(f"{result['verdict']} (confidence {result['confidence']:.1%})")
    for word, w in result["top_words"]:
        print(f"  {word:25s} {'+' if w > 0 else '-'}{abs(w):.3f}")
