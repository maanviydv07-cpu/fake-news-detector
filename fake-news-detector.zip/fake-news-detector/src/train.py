"""Train several classifiers, compare them, and save the best pipeline.

Usage:
    python -m src.train --data-dir data
"""
import argparse
import json
from pathlib import Path

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression, PassiveAggressiveClassifier
from sklearn.metrics import (ConfusionMatrixDisplay, accuracy_score,
                             classification_report, f1_score)
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

from src.preprocess import clean_text

ROOT = Path(__file__).resolve().parent.parent


def load_data(data_dir: Path) -> pd.DataFrame:
    """Load Fake.csv / True.csv. Label 0 = fake, 1 = real."""
    fake = pd.read_csv(data_dir / "Fake.csv")
    real = pd.read_csv(data_dir / "True.csv")
    fake["label"], real["label"] = 0, 1
    df = pd.concat([fake, real], ignore_index=True)
    df["content"] = (df["title"].fillna("") + " " + df["text"].fillna("")).map(clean_text)
    df = df[df["content"].str.len() > 20]
    df = df.drop_duplicates(subset="content")  # duplicates would leak across splits
    return df[["content", "label"]]


def build_models() -> dict:
    return {
        "Logistic Regression": LogisticRegression(max_iter=1000),
        "Linear SVM": LinearSVC(),
        "Passive Aggressive": PassiveAggressiveClassifier(max_iter=50, random_state=42),
        "Multinomial NB": MultinomialNB(),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=ROOT / "data")
    parser.add_argument("--test-size", type=float, default=0.2)
    parser.add_argument("--min-df", type=int, default=5)
    args = parser.parse_args()

    df = load_data(args.data_dir)
    print(f"Loaded {len(df)} articles | real={df.label.sum()} fake={(df.label == 0).sum()}")

    X_train, X_test, y_train, y_test = train_test_split(
        df["content"], df["label"], test_size=args.test_size,
        stratify=df["label"], random_state=42)

    results, best = {}, (None, -1, None, None)
    for name, clf in build_models().items():
        pipe = Pipeline([
            ("tfidf", TfidfVectorizer(stop_words="english", max_df=0.7,
                                      min_df=args.min_df, ngram_range=(1, 2),
                                      max_features=100_000)),
            ("clf", clf),
        ])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        acc, f1 = accuracy_score(y_test, pred), f1_score(y_test, pred)
        results[name] = {"accuracy": round(acc, 4), "f1": round(f1, 4)}
        print(f"{name:22s} accuracy={acc:.4f}  f1={f1:.4f}")
        if f1 > best[1]:
            best = (name, f1, pipe, pred)

    name, _, pipe, pred = best
    print(f"\nBest model: {name}\n")
    print(classification_report(y_test, pred, target_names=["Fake", "Real"]))

    (ROOT / "models").mkdir(exist_ok=True)
    (ROOT / "reports").mkdir(exist_ok=True)
    joblib.dump(pipe, ROOT / "models" / "model.joblib")
    with open(ROOT / "reports" / "metrics.json", "w") as f:
        json.dump({"best_model": name, "results": results}, f, indent=2)

    ConfusionMatrixDisplay.from_predictions(
        y_test, pred, display_labels=["Fake", "Real"], cmap="Blues")
    plt.title(f"Confusion Matrix - {name}")
    plt.savefig(ROOT / "reports" / "confusion_matrix.png", dpi=150, bbox_inches="tight")
    print("Saved model to models/model.joblib and reports to reports/")


if __name__ == "__main__":
    main()
